<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('global.team.title')); ?>

    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <tbody>
                <tr>
                    <th>
                        <?php echo e(trans('global.team.fields.logo')); ?>

                    </th>
                    <td>
                        <img src="<?php echo e(url('/images/team-logos/'.$team->logoUri)); ?>" alt="<?php echo e($team->name); ?>" height="80" width="80" />
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.team.title_singular')); ?>

                    </th>
                    <td>
                        <?php echo e($team->name); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.team.fields.club_state')); ?>

                    </th>
                    <td>
                        <?php echo e($team->club_state); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.team.title_players')); ?>

                    </th>
                    <td>
                        <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>
                            <u><b><?php echo e($player->firstName.' '.$player->lastName); ?></b></u>
                            <u><p><?php echo e(trans('global.team.title_player_history')); ?>: </p></u>
                        <!-- <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.players.show', $player->id)); ?>">
                                        <?php echo e($player->firstName.' '.$player->lastName); ?>

                        </a> --></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <tr>
                    <th></th>
                    <td><a href="<?php echo e(url()->previous()); ?>" class="btn btn-info">Back</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/teams/show.blade.php ENDPATH**/ ?>