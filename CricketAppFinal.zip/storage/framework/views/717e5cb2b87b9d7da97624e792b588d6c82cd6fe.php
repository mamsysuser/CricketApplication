<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 10px;" class="row">
   <div class="col-lg-12">
      <a class="btn btn-success" href="<?php echo e(route("admin.teams.create")); ?>">
      <?php echo e(trans('global.add')); ?> <?php echo e(trans('global.team.title_singular')); ?>

      </a>
   </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
   <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
<div class="alert alert-error">
   <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="card">
   <div class="card-header">
      <?php echo e(trans('global.team.title_singular')); ?> <?php echo e(trans('global.list')); ?>

   </div>
   <div class="card-body">
      <div class="table-responsive">
         <table class=" table table-bordered table-striped table-hover datatable">
            <thead>
               <tr>
                  <th>
                     <?php echo e(trans('global.team.fields.logo')); ?>

                  </th>
                  <th>
                     <?php echo e(trans('global.team.fields.name')); ?>

                  </th>
                  <th>
                     <?php echo e(trans('global.team.fields.club_state')); ?>

                  </th>
                  <th>
                     &nbsp;
                  </th>
               </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr data-entry-id="<?php echo e($team->id); ?>">
                  <td>
                     <img src="<?php echo e(url('/images/team-logos/'.$team->logoUri)); ?>" alt="<?php echo e($team->name); ?>" height="50" width="50" />
                  </td>
                  <td>
                     <a class="" href="#" id= "<?php echo e($team->id); ?>" data-toggle="modal" data-target="#teamInfo<?php echo e($team->id); ?>">
                     <?php echo e($team->name ?? ''); ?>

                     </a>
                  </td>
                  <td>
                     <?php echo e($team->club_state ?? ''); ?>

                  </td>
                  <td>
                     <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.teams.edit', $team->id)); ?>">
                     <?php echo e(trans('global.edit')); ?>

                     </a>
                     <form action="<?php echo e(route('admin.teams.destroy', $team->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                     </form>
                  </td>
               </tr>
               <!-- Modal -->
               <div class="modal fade" id="teamInfo<?php echo e($team->id); ?>" tabindex="-1" role="dialog" aria-labelledby="teamlabel<?php echo e($team->id); ?>"
                  aria-hidden="true">
                  <div class="modal-dialog" role="document">
                     <div class="modal-content">
                        <div class="modal-header">
                           <span><img src="<?php echo e(url('/images/team-logos/'.$team->logoUri)); ?>" alt="<?php echo e($team->name); ?>" height="50" width="50" /></span>&nbsp;&nbsp;
                           <span>
                              <h5 class="modal-title" id="teamlabel<?php echo e($team->id); ?>"><b><?php echo e($team->name); ?></b></h5>
                              <b><?php echo e(trans('global.team.fields.club_state')); ?></b> <?php echo e($team->club_state); ?>

                           </span>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        <div class="modal-body mx-3">
                           <div class='form-row'>
                              <div class="col-xs-12 form-group">
                                 <label class='control-label'><b><u><?php echo e(trans('global.player.title')); ?></u></b></label>    
                              </div>
                           </div>
                           <?php if(count($team->players) > 0): ?>
                           <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php
                              $history = unserialize($player->player_history);
                           ?>
                           <div class='form-row'>
                              <div class="col-xs-12 form-group">
                                 <img src="<?php echo e(url('/images/player-logos/'.$player->imageUri)); ?>" alt="<?php echo e($player->firstName); ?>" height="50" width="50" />
                                 <label class='control-label'><b><?php echo e($player->firstName.' '.$player->lastName); ?>:</b>  <p><b><?php echo e(trans('global.player.fields.jerseyNo')); ?>:</b> <?php echo e($player->jerseyNo); ?>, <b><?php echo e(trans('global.player.fields.matches')); ?>:</b> <?php echo e($history['matches']); ?>, <b><?php echo e(trans('global.player.fields.runs')); ?>:</b> <?php echo e($history['runs']); ?>, <b><?php echo e(trans('global.player.fields.highest_score')); ?>:</b> <?php echo e($history['highest_score']); ?>, <b><?php echo e(trans('global.player.fields.hundreds')); ?>:</b> <?php echo e($history['hundreds']); ?>, <b><?php echo e(trans('global.player.fields.fifties')); ?>:</b> <?php echo e($history['fifties']); ?>, <b><?php echo e(trans('global.player.fields.wickets')); ?>:</b> <?php echo e($history['wickets']); ?></p></label>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?>
                           <p>No player exist in this team. Click here to <a class="" href="<?php echo e(route('admin.players.create' )); ?>">create players and assign team</a></p>
                           <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/teams/index.blade.php ENDPATH**/ ?>