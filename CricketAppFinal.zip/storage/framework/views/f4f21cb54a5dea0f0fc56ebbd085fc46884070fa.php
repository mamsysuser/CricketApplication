<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('global.match.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.matches.update", [$match->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('match_title') ? 'has-error' : ''); ?>">
                <label for="firstName"><?php echo e(trans('global.match.fields.match_title')); ?>*</label>
                <input type="text" id="match_title" name="match_title" class="form-control" value="<?php echo e(old('match_title', isset($match) ? $match->match_title : '')); ?>" placeholder="<?php echo e(trans('global.match.fields.match_title')); ?>">
                <?php if($errors->has('match_title')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('match_title')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('firstteam_id') ? 'has-error' : ''); ?>">
                <label for="firstteam_id"><?php echo e(trans('global.match.fields.firstteam_id')); ?>*</label>
                <select class="form-control" name="firstteam_id" id="firstteam_id">
                  <option value="" selected>Select First Team</option>
                  <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"
                    <?php echo e($match->firstteam_id == $key ? 'selected' : ''); ?>

                    > 
                        <?php echo e($value); ?> 
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </select>
                <?php if($errors->has('firstteam_id')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('firstteam_id')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('secondteam_id') ? 'has-error' : ''); ?>">
                <label for="secondteam_id"><?php echo e(trans('global.match.fields.secondteam_id')); ?>*</label>
                <select class="form-control" name="secondteam_id" id="secondteam_id">
                  <option value="" selected>Select Second Team</option>
                  <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"
                    <?php echo e($match->secondteam_id == $key ? 'selected' : ''); ?>

                    > 
                        <?php echo e($value); ?> 
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </select>
                <?php if($errors->has('second_team_id')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('second_team_id')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('winningteam_id') ? 'has-error' : ''); ?>">
                <label for="winningteam_id"><?php echo e(trans('global.match.fields.winningteam_id')); ?>*</label>
                <select class="form-control" name="winningteam_id" id="winningteam_id">
                  <option value="" selected>Select Winning Team</option>
                  <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"
                    <?php echo e($match->winningteam_id == $key ? 'selected' : ''); ?>

                    > 
                        <?php echo e($value); ?> 
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </select>
                <?php if($errors->has('winningteam_id')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('winningteam_id')); ?>

                    </em>
                <?php endif; ?>
            </div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Back</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/matches/edit.blade.php ENDPATH**/ ?>