<?php $__env->startSection('content'); ?>

    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route("admin.players.create")); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('global.player.title_singular')); ?>

            </a>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
    <div class="alert alert-error">
       <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.player.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th>
                            <?php echo e(trans('global.player.fields.image')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.player.fields.lastname')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.player.fields.firstname')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($player->id); ?>">
                            <td>
                                <img src="<?php echo e(url('/images/player-logos/'.$player->imageUri)); ?>" alt="<?php echo e($player->firstName); ?>" height="50" width="50" />
                            </td>
                            <td>
                                <?php echo e($player->lastName ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($player->firstName ?? ''); ?>

                            </td>
                            <td>
                                <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.players.show', $player->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                </a>
                                <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.players.edit', $player->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <form action="<?php echo e(route('admin.players.destroy', $player->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/players/index.blade.php ENDPATH**/ ?>