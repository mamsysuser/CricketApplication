<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('global.team.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.teams.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('global.team.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($team) ? $team->name : '')); ?>">
                <?php if($errors->has('name')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('logoUri') ? 'has-error' : ''); ?>">
                <label for="logoUri"><?php echo e(trans('global.team.fields.logo')); ?></label>
                <input type="file" name="logoUri" class="form-control" value="<?php echo e(old('logoUri', isset($team) ? $team->logoUri : '')); ?>">
                <?php if($errors->has('logoUri')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('logoUri')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('club_state') ? 'has-error' : ''); ?>">
                <label for="club_state"><?php echo e(trans('global.team.fields.club_state')); ?></label>
                <input type="text" id="club_state" name="club_state" class="form-control" value="<?php echo e(old('club_state', isset($team) ? $team->club_state : '')); ?>" step="0.01">
                <?php if($errors->has('club_state')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('club_state')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Back</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/fixtures/index.blade.php ENDPATH**/ ?>