<?php $__env->startSection('content'); ?>
<div class="card">
   <div class="card-header">
      <?php echo e(trans('global.create')); ?> <?php echo e(trans('global.player.title_singular')); ?>

   </div>
   <div class="card-body">
      <form action="<?php echo e(route("admin.players.store")); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group <?php echo e($errors->has('team_id') ? 'has-error' : ''); ?>">
         <label for="team_id"><?php echo e(trans('global.team.title_singular')); ?>*</label>
         <select class="form-control" name="team_id" id="team_id">
            <option value="" selected>Select Team</option>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>"> 
               <?php echo e($value); ?> 
            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
         </select>
         <?php if($errors->has('team_id')): ?>
         <em class="invalid-feedback">
         <?php echo e($errors->first('team_id')); ?>

         </em>
         <?php endif; ?>
      </div>
      <div class="form-group <?php echo e($errors->has('firstName') ? 'has-error' : ''); ?>">
         <label for="firstName"><?php echo e(trans('global.player.fields.firstname')); ?>*</label>
         <input type="text" id="firstName" name="firstName" class="form-control" value="<?php echo e(old('firstName', isset($player) ? $player->firstName : '')); ?>">
         <?php if($errors->has('firstName')): ?>
         <em class="invalid-feedback">
         <?php echo e($errors->first('firstName')); ?>

         </em>
         <?php endif; ?>
      </div>
      <div class="form-group <?php echo e($errors->has('lastName') ? 'has-error' : ''); ?>">
         <label for="lastName"><?php echo e(trans('global.player.fields.lastname')); ?>*</label>
         <input type="text" id="lastName" name="lastName" class="form-control" value="<?php echo e(old('lastName', isset($player) ? $player->lastName : '')); ?>">
         <?php if($errors->has('lastName')): ?>
         <em class="invalid-feedback">
         <?php echo e($errors->first('lastName')); ?>

         </em>
         <?php endif; ?>
      </div>
      <div class="form-group <?php echo e($errors->has('imageUri') ? 'has-error' : ''); ?>">
         <label for="imageUri"><?php echo e(trans('global.player.fields.image')); ?></label>
         <input type="file" name="imageUri" class="form-control" value="<?php echo e(old('imageUri', isset($player) ? $player->imageUri : '')); ?>">
         <?php if($errors->has('imageUri')): ?>
         <em class="invalid-feedback">
         <?php echo e($errors->first('imageUri')); ?>

         </em>
         <?php endif; ?>
      </div>
      <div class="form-group <?php echo e($errors->has('jerseyNo') ? 'has-error' : ''); ?>">
         <label for="jerseyNo"><?php echo e(trans('global.player.fields.jerseyNo')); ?>*</label>
         <input type="text" id="jerseyNo" name="jerseyNo" class="form-control" value="<?php echo e(old('jerseyNo', isset($player) ? $player->jerseyNo : '')); ?>">
         <?php if($errors->has('jerseyNo')): ?>
         <em class="invalid-feedback">
         <?php echo e($errors->first('jerseyNo')); ?>

         </em>
         <?php endif; ?>
      </div>
      <div class="form-group <?php echo e($errors->has('country_id') ? 'has-error' : ''); ?>">
         <label for="country_id"><?php echo e(trans('global.player.fields.country')); ?>*</label>
         <select class="form-control" name="country_id" id="country_id">
            <option>Country</option>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>"> 
               <?php echo e($value); ?> 
            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
         </select>
         <?php if($errors->has('country_id')): ?>
         <em class="invalid-feedback">
         <?php echo e($errors->first('country_id')); ?>

         </em>
         <?php endif; ?>
      </div>
      <div class="form-row">
         <div class="form-group col-md-4">
            <label for="inputCity"><?php echo e(trans('global.player.fields.matches')); ?></label>
            <input type="text" class="form-control" id="matches" name="matches">
            <?php if($errors->has('matches')): ?>
             <em class="invalid-feedback">
             <?php echo e($errors->first('matches')); ?>

             </em>
            <?php endif; ?>
         </div>
         <div class="form-group col-md-4">
            <label for="inputState"><?php echo e(trans('global.player.fields.runs')); ?></label>
            <input type="text" class="form-control" id="runs" name="runs">
            <?php if($errors->has('runs')): ?>
             <em class="invalid-feedback">
             <?php echo e($errors->first('runs')); ?>

             </em>
            <?php endif; ?>
         </div>
         <div class="form-group col-md-4">
            <label for="inputZip"><?php echo e(trans('global.player.fields.highest_score')); ?></label>
            <input type="text" class="form-control" id="highest_score" name="highest_score">
            <?php if($errors->has('highest_score')): ?>
             <em class="invalid-feedback">
             <?php echo e($errors->first('highest_score')); ?>

             </em>
            <?php endif; ?>
         </div>
      </div>
      <div class="form-row">
         <div class="form-group col-md-4">
            <label for="inputCity"><?php echo e(trans('global.player.fields.hundreds')); ?></label>
            <input type="text" class="form-control" id="hundreds" name="hundreds">
            <?php if($errors->has('hundreds')): ?>
             <em class="invalid-feedback">
             <?php echo e($errors->first('hundreds')); ?>

             </em>
            <?php endif; ?>
         </div>
         <div class="form-group col-md-4">
            <label for="inputState"><?php echo e(trans('global.player.fields.fifties')); ?></label>
            <input type="text" class="form-control" id="fifties" name="fifties">
            <?php if($errors->has('fifties')): ?>
             <em class="invalid-feedback">
             <?php echo e($errors->first('fifties')); ?>

             </em>
            <?php endif; ?>
         </div>
         <div class="form-group col-md-4">
            <label for="inputZip"><?php echo e(trans('global.player.fields.wickets')); ?></label>
            <input type="text" class="form-control" id="wickets" name="wickets">
            <?php if($errors->has('wickets')): ?>
             <em class="invalid-feedback">
             <?php echo e($errors->first('wickets')); ?>

             </em>
            <?php endif; ?>
         </div>
      </div>
      <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
      <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Back</a>
   </div>
   </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/players/create.blade.php ENDPATH**/ ?>