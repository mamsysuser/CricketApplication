<?php $__env->startSection('content'); ?>

    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route("admin.matches.create")); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('global.match.title_singular')); ?>

            </a>
            <a class="btn btn-success" href="<?php echo e(route("admin.fixtures.show",1)); ?>">
                <?php echo e(trans('global.match.title_fixtures')); ?>

            </a>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('info')): ?>
        <div class="alert alert-info">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
    <div class="alert alert-error">
       <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-warning alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button> 
            <strong><?php echo e($message); ?></strong>
        </div>  
    <?php endif; ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.match.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th>
                            <?php echo e(trans('global.match.fields.match_title')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.match.fields.firstteam_id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.match.fields.secondteam_id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.match.fields.winningteam_id')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($match->id); ?>">
                            <td>
                                <?php echo e($match->match_title ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($match->FirstTeam->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($match->SecondTeam->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($match->WinningTeam->name ?? 'Result awaited...'); ?>

                            </td>
                            <td>
                                <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.matches.show', $match->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                </a>
                                <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.matches.edit', $match->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <form action="<?php echo e(route('admin.matches.destroy', $match->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/matches/index.blade.php ENDPATH**/ ?>