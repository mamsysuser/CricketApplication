<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('global.player.title')); ?>

    </div>

    <div class="card-body">
        <table class="table table-bordered table-striped">
            <tbody>
                <tr>
                    <th>
                        <?php echo e(trans('global.player.fields.image')); ?>

                    </th>
                    <td>
                        <img src="<?php echo e(url('/images/player-logos/'.$player->imageUri)); ?>" alt="<?php echo e($player->fiestName); ?>" height="80" width="80" />
                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.player.fields.lastname')); ?>

                    </th>
                    <td>
                        <?php echo e($player->lastName); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.player.fields.firstname')); ?>

                    </th>
                    <td>
                        <?php echo e($player->firstName); ?>

                    </td>
                </tr>
                <tr>
                    <th></th>
                    <td><a href="<?php echo e(url()->previous()); ?>" class="btn btn-info">Back</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/players/show.blade.php ENDPATH**/ ?>