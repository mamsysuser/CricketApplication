<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('global.match.title')); ?>

    </div>

    <div class="card-body">
        <table class="table table-bordered table-striped">
            <tbody>
                <tr>
                    <th>
                        <?php echo e(trans('global.match.fields.firstteam_id')); ?>

                    </th>
                    <td>
                        <?php echo e($match->firstteam_id); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.match.fields.secondteam_id')); ?>

                    </th>
                    <td>
                        <?php echo e($match->secondteam_id); ?>

                    </td>
                </tr>
                <tr>
                    <th>
                        <?php echo e(trans('global.match.fields.winningteam_id')); ?>

                    </th>
                    <td>
                        <?php echo e($match->winningteam_id); ?>

                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/matches/show.blade.php ENDPATH**/ ?>