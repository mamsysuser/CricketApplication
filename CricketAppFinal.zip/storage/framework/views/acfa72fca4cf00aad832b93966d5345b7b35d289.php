<div class="sidebar">
    <nav class="sidebar-nav ps ps--active-y">

        <ul class="nav">
            <li class="nav-item">
                <a href="<?php echo e(route("admin.home")); ?>" class="nav-link">
                    <i class="nav-icon fas fa-tachometer-alt">

                    </i>
                    <?php echo e(trans('global.dashboard')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.teams.index")); ?>" class="nav-link <?php echo e(request()->is('admin/teams') || request()->is('admin/teams/*') ? 'active' : ''); ?>">
                    <i class="fas fa-cogs nav-icon">

                    </i>
                    <?php echo e(trans('global.team.title')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.players.index")); ?>" class="nav-link <?php echo e(request()->is('admin/players') || request()->is('admin/players/*') ? 'active' : ''); ?>">
                    <i class="fas fa-cogs nav-icon">

                    </i>
                    <?php echo e(trans('global.player.title')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.matches.index")); ?>" class="nav-link <?php echo e(request()->is('admin/matches') || request()->is('admin/matches/*') ? 'active' : ''); ?>">
                    <i class="fas fa-cogs nav-icon">

                    </i>
                    <?php echo e(trans('global.match.title')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.points.index")); ?>" class="nav-link <?php echo e(request()->is('admin/points') || request()->is('admin/points/*') ? 'active' : ''); ?>">
                    <i class="fas fa-cogs nav-icon">

                    </i>
                    <?php echo e(trans('global.point.title')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="nav-icon fas fa-sign-out-alt">

                    </i>
                    <?php echo e(trans('global.logout')); ?>

                </a>
            </li>
        </ul>

        <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
            <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
        </div>
        <div class="ps__rail-y" style="top: 0px; height: 869px; right: 0px;">
            <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 415px;"></div>
        </div>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div><?php /**PATH /var/www/html/cricketapplication/resources/views/partials/menu.blade.php ENDPATH**/ ?>