<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.point.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('global.point.fields.team')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('global.point.fields.points')); ?>

                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($point->id); ?>">
                            <td>
                             <img src="<?php echo e(url('/images/team-logos/'.$point->team->logoUri)); ?>" alt="<?php echo e($point->team->name); ?>" height="50" width="50" />
                            </td>
                            <td>
                                <?php echo e($point->team->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($point->total_points ?? ''); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cricketapplication/resources/views/admin/points/index.blade.php ENDPATH**/ ?>